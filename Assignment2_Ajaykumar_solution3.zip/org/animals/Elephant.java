package org.animals;

public class Elephant {
	String colour="Grey";
	int weight=1000;
	int age=25;
	public void elephantDetails() {
		System.out.println("Elephant colour is :"+colour);
		System.out.println("Elephant weight is:"+weight);
		System.out.println("Elephant age is :"+age);
		}

	public void isVegetarian() {
		
		System.out.println("Yes Elephant is vegetarian");
	}
public void canClimb() {
	System.out.println("No Elephant cant climb");
}
public void getSound() {
	System.out.println("Elephant sound is Trumpet");
}
}
