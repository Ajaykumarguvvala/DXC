package org.animals;

public class Lion {
	String colour="Yellow";
	int weight=190;
	int age=15;
	public void lionDetails() {
		System.out.println("Lion colour is :"+colour);
		System.out.println("Lion weight is:"+weight);
		System.out.println("Lion age is :"+age);
	}
	public void isVegetarian() {
		System.out.println(("No Lion is not vegetarian"));
	}
	public void canClimb() {
		System.out.println("No Lion can't climb");
	}
	public void getSound() {
		System.out.println("Lion will Roar");
	}
	

}
