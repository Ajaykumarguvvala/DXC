package org.animals;

public class Monkey {
	String colour="Brown";
	int weight=50;
	int age=10;

	public void monkeyDetails() {
		System.out.println("Monkey colour is :"+colour);
		System.out.println("Monkey weight is:"+weight);
		System.out.println("Monkey age is :"+age);
		
	}	
public void isVegetarian() {
	System.out.println("Yes Monkey is vegetarian");
}
public void canClimb() {
	System.out.println( "Yes Monkey can climb");
}
public void getSound() {
	System.out.println("Monkeys sound is screech");
}
}
