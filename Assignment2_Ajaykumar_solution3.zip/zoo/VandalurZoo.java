package zoo;
import org.animals.*;

public class VandalurZoo {
	public static void main(String[] args) {
		
	    Lion li = new Lion();
		li.lionDetails();
		li.isVegetarian();
		li.canClimb();
		li.getSound();
		
		Monkey mo = new Monkey();
		mo.monkeyDetails();
		mo.isVegetarian();
		mo.canClimb();
		mo.getSound();
		
		Elephant ee = new Elephant();
		ee.elephantDetails();
		ee.isVegetarian();
		ee.canClimb();
		ee.getSound();
		
		
	}

}
